#!/bin/bash 

echo "Generating log file..."
touch log.txt
sleep 2

echo "Registering login..."
user=$USER
date=$(date +%Y_%m_%d__%H:%M:%S)
sleep  2


echo "$user/$date" >> log.txt
sleep 2 

echo -e "Login Registered\n"
cat log.txt

