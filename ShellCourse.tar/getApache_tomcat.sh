#!/bin/bash 
#getting INF from the >Web.


echo "Download something from Web"

wget https://downloads.apache.org/tomcat/tomcat-8/v8.5.81/bin/apache-tomcat-8.5.81.tar.gz 

