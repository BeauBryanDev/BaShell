#!/bin/bash 
#check the Arguments by $*

nameof=$1

timeof=$2

echo " The course name is $nameof and the schedule is $timeof h.am "
echo " Number of Parameters is $# "
echo " The Parameters are $* " 




