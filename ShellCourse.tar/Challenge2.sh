#!/bin/bash 
#Ask for User Information . 

firstName=""; RegexWords='^[A-Z a-z]{2,35}$'
lastName="";
age=0, regexAge='^([1-9]{1,2})$'


