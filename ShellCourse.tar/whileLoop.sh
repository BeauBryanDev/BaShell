#!/bin/bash 

#Getting into While Loop.

i=1

while [ $i -le 15 ]
do

    echo "Printiing $i "
    i=$((i+1))

done 


