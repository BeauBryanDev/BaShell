#!/bin/bash

#Reto1__Bash_Programming .

echo "Please, Enter your Name inside \"\" over here " 
read name 
echo "Please, Enter your last Names with same format as above"
read lastname 
echo "Enter you age as well"
read age

echo "Hello $name $lastname , You are $age years old." 



