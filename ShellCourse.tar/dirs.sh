#!/bin/bash 

mycurrentdir=$(pwd)

echo "my current directory path is this one " $mycurrentdir


