#!/bin/bash 
#option menu.

option=0

        clear
        echo"███████████████████████████"
        echo"███████▀▀▀░░░░░░░▀▀▀███████"
        echo"████▀░░░░░░░░░░░░░░░░░▀████"
        echo"███│░░░░░░░░░░░░░░░░░░░│███"
        echo"██▌│░░░░░░░░░░░░░░░░░░░│▐██"
        echo"██░└┐░░░░░░░░░░░░░░░░░┌┘░██"
        echo"██░░└┐░░░░░░░░░░░░░░░┌┘░░██"
        echo"██░░┌┘     ░░░░░     └┐░░██"
        echo"██▌░│       ░░░       │░▐██"
        echo"███░│      ░░ ░░      │░███"
        echo"██▀─┘░░░░░░░   ░░░░░░░└─▀██"
        echo"██▄░░░    ░░   ░░    ░░░▄██"
        echo"████▄─┘   ░░░░░░░   └─▄████"
        echo"█████░░  ─┬┬┬┬┬┬┬─  ░░█████"
        echo"████▌░░░ ┬┼┼┼┼┼┼┼  ░░░▐████"
        echo"█████▄░░░└┴┴┴┴┴┴┴┘░░░▄█████"
        echo"███████▄░░░░░░░░░░░▄███████"
        echo"██████████▄▄▄▄▄▄▄██████████"
        echo"███████████████████████████"
        echo"LOADING...LOADING...LOADING"
        sleep 0.3

while  :

do 

    #clear 

    echo -e "\n"

    echo "*******************************"
    echo "==============================="
    echo "PGUTIL - Postgres_Utilities>>>>"
    echo "==============================="
    echo "         Main Menu             "
    echo "==============================="
    echo "*******************************"

    echo "1. Install Postgres "
    echo "2. UnIstall Postgres"
    echo "3, Make a BackUp"
    echo "4. Restore BackUp"
    echo "5. Exit the Program"

    #Read whatever is the User Option ...

    read -n2 -p "Enter a valid Option [1-5] : " option

    #vValidate the INF input by User. ...
echo -e "\n"

    case $option in 
        
        1) 
            echo -e "\nYou Chose to Install Postgres"
            sleep 2
            ;;
        2) 
            echo -e "\nYou Chose to Unistall Postgres"
            sleep 2
            ;;
        3)
            echo -e "\nYou Chose to Make a Backup"
            sleep 2
            ;;
        4) 
            echo -e "\nYou Chose to Restore Backup"
            sleep 2
            ;;
        5) 
            echo -e "\nYou Chose to Leave as Exit "
            exit 0 
            ;;
        *)  
            echo -e "\nInValid Option , Try Again"
            sleep 1
            ;;

    esac

done








