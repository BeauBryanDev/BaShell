#!/bin/bash 

actuaLocation=`pwd`
KernelInf=$(uname -a)
    
    echo "Current Location is : $actuaLocation"
    echo "Kernel >>Information : $KernelInf"


