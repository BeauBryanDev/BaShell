#!/bin/bash 
#utilitarios dePostgres

echo "Hello Dear Bryan!" 

echo "Hey ** $1!! "



