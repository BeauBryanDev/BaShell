#!/bin/bash 

#Testing Program 

echo "Name from the first script as : $name1"

#Export the variable name to be available in other process.  


